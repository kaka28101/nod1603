// for (console.log(1); console.log(2); console.log(3)) {
//     console.log('h');
// }

// let i = 0;

// while (true) {
//     console.log(i++);
//     if(i == 6) break;
// }

let a = 5, b = 10;

if(a > 100 & b++ > 5) {
    console.log('DUNG', b);
} else {
    console.log('DUNG', b);
}

