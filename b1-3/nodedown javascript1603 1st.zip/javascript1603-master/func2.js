function download(callback){
    callback('Sai gon hom nay co mua!');
}

const aFunction = function(str){
    console.log(str);
}

download(aFunction);