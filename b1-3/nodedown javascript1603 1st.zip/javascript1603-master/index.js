// let a = 'Xin chao';

// let a = 10;
// let b = '10';

// console.log( a !== b );

let a = true;
let b = false;
let c = 10;
// console.log(c /= 5);

let d = 10;
let e = 10;
// 0, null, undefined, false

    // if(aVar) {
    //     max = d;
    // } else {
    //     max = e;
    // }

// let max = d - e ? d : e + 1;

// console.log( typeof null );

// console.log(max);
let g = 100;
let h = 101;
// console.log((g++, g + h));

if(null) console.log("Xin chao ban");

