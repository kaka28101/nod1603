// function a() {
//     console.log('AAA');
// }

//arrow function

const a = e => e * e;

console.log(a(10));