// let a = 5;
// let b = a;
// a++;
// console.log(b);

let a = { value: 5 };
let b = a;
a = {value: 10};
console.log(b);